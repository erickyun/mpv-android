import SwiftUI

struct AdvancedSettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @Environment(\.dismiss) private var dismiss

    @State private var apiKey = ""
    @State private var saveMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("Use TorBox for torrents", isOn: $settings.torBoxEnabled)

                    SecureField("TorBox API key", text: $apiKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .privacySensitive()

                    Button("Save API key") {
                        do {
                            try settings.saveTorBoxAPIKey(apiKey)
                            saveMessage = "API key saved securely."
                        } catch {
                            saveMessage = error.localizedDescription
                        }
                    }
                } header: {
                    Text("TorBox")
                } footer: {
                    Text("The API key is stored in the iOS Keychain. TorBox is tried before TorrServer.")
                }

                Section {
                    Toggle("Use TorrServer for torrents", isOn: $settings.torrServerEnabled)

                    TextField("TorrServer address", text: $settings.torrServerAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                } header: {
                    Text("TorrServer")
                } footer: {
                    Text("Example: http://192.168.1.10:8090. Use 127.0.0.1 only when TorrServer runs on this iPhone.")
                }

                Section("Provider priority") {
                    Text("TorBox → TorrServer fallback → Direct media URL")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

                if let saveMessage {
                    Section {
                        Text(saveMessage)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Advanced")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }
                }
            }
            .onAppear {
                apiKey = settings.torBoxAPIKey
            }
        }
    }
}
