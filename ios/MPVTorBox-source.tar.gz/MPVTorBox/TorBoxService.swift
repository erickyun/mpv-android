import Foundation

actor TorBoxService {
    enum ServiceError: LocalizedError {
        case invalidAPIKey
        case invalidResponse
        case api(String)
        case noTorrentID
        case noPlayableFile
        case timedOut

        var errorDescription: String? {
            switch self {
            case .invalidAPIKey:
                return "Enter a TorBox API key in Advanced settings."
            case .invalidResponse:
                return "TorBox returned an invalid response."
            case .api(let message):
                return message
            case .noTorrentID:
                return "TorBox did not return a torrent ID."
            case .noPlayableFile:
                return "No playable video file was found in the torrent."
            case .timedOut:
                return "TorBox did not make the file ready before the request timed out."
            }
        }
    }

    private let baseURL = URL(string: "https://api.torbox.app/v1/api/torrents")!
    private let session: URLSession
    private let videoExtensions = Set([
        "mkv", "mp4", "m4v", "mov", "avi", "webm", "ts", "m2ts",
        "mpg", "mpeg", "flv", "wmv", "ogv"
    ])

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 120
        configuration.waitsForConnectivity = true
        session = URLSession(configuration: configuration)
    }

    func resolve(
        magnet: String,
        apiKey: String,
        status: @escaping @MainActor (String) -> Void
    ) async throws -> URL {
        let token = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !token.isEmpty else { throw ServiceError.invalidAPIKey }

        await status("Adding magnet to TorBox…")
        let torrentID = try await createTorrent(magnet: magnet, apiKey: token)

        for attempt in 1...30 {
            await status("Waiting for TorBox file \(attempt)/30…")

            do {
                let item = try await fetchTorrent(id: torrentID, apiKey: token)
                if let file = selectPlayableFile(from: item) {
                    do {
                        await status("Requesting TorBox stream…")
                        return try await requestDownload(
                            torrentID: torrentID,
                            fileID: file.id,
                            apiKey: token
                        )
                    } catch {
                        if attempt == 30 { throw error }
                    }
                }
            } catch {
                if attempt == 30 { throw error }
            }

            try await Task.sleep(nanoseconds: 3_000_000_000)
        }

        throw ServiceError.timedOut
    }

    private func createTorrent(magnet: String, apiKey: String) async throws -> Int {
        let url = baseURL.appendingPathComponent("createtorrent")
        let boundary = "Boundary-\(UUID().uuidString)"
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        body.appendUTF8("--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"magnet\"\r\n\r\n")
        body.appendUTF8(magnet)
        body.appendUTF8("\r\n--\(boundary)\r\n")
        body.appendUTF8("Content-Disposition: form-data; name=\"seed\"\r\n\r\n")
        body.appendUTF8("3")
        body.appendUTF8("\r\n--\(boundary)--\r\n")
        request.httpBody = body

        let object = try await performJSON(request)
        try validateSuccess(object)

        if let data = object["data"] {
            if let id = integer(in: data, preferredKeys: ["torrent_id", "id"]) {
                return id
            }
            if let number = data as? NSNumber {
                return number.intValue
            }
        }

        if let id = integer(in: object, preferredKeys: ["torrent_id"]) {
            return id
        }

        throw ServiceError.noTorrentID
    }

    private func fetchTorrent(id: Int, apiKey: String) async throws -> Any {
        var components = URLComponents(
            url: baseURL.appendingPathComponent("mylist"),
            resolvingAgainstBaseURL: false
        )!
        components.queryItems = [
            URLQueryItem(name: "id", value: String(id)),
            URLQueryItem(name: "bypass_cache", value: "true")
        ]

        var request = URLRequest(url: components.url!)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")

        let object = try await performJSON(request)
        try validateSuccess(object)

        guard let data = object["data"] else {
            throw ServiceError.invalidResponse
        }

        if let list = data as? [Any] {
            guard let matching = list.first(where: {
                integer(in: $0, preferredKeys: ["id", "torrent_id"]) == id
            }) ?? list.first else {
                throw ServiceError.invalidResponse
            }
            return matching
        }

        return data
    }

    private func requestDownload(torrentID: Int, fileID: Int, apiKey: String) async throws -> URL {
        var components = URLComponents(
            url: baseURL.appendingPathComponent("requestdl"),
            resolvingAgainstBaseURL: false
        )!
        components.queryItems = [
            URLQueryItem(name: "token", value: apiKey),
            URLQueryItem(name: "torrent_id", value: String(torrentID)),
            URLQueryItem(name: "file_id", value: String(fileID)),
            URLQueryItem(name: "redirect", value: "false"),
            URLQueryItem(name: "append_name", value: "true")
        ]

        var request = URLRequest(url: components.url!)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")

        let object = try await performJSON(request)
        try validateSuccess(object)

        if let value = findURLString(in: object),
           let url = URL(string: value) {
            return url
        }

        throw ServiceError.invalidResponse
    }

    private func selectPlayableFile(from object: Any) -> MediaFile? {
        let fileObjects = arrays(named: "files", in: object).flatMap { $0 }
        let files = fileObjects.compactMap(parseMediaFile)

        let videos = files.filter {
            videoExtensions.contains(URL(fileURLWithPath: $0.name).pathExtension.lowercased())
        }

        return (videos.isEmpty ? files : videos).max { $0.size < $1.size }
    }

    private func parseMediaFile(_ object: Any) -> MediaFile? {
        guard let dictionary = object as? [String: Any],
              let id = integer(in: dictionary, preferredKeys: ["id", "file_id"]) else {
            return nil
        }

        let name = string(in: dictionary, keys: ["short_name", "name", "path", "filename"])
            ?? "File \(id)"
        let size = int64(in: dictionary, keys: ["size", "bytes", "filesize"]) ?? 0
        return MediaFile(id: id, name: name, size: size)
    }

    private func performJSON(_ request: URLRequest) async throws -> [String: Any] {
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw ServiceError.invalidResponse
        }

        let rawObject = try? JSONSerialization.jsonObject(with: data)
        let object = rawObject as? [String: Any]

        guard (200...299).contains(http.statusCode) else {
            throw ServiceError.api(
                message(from: object)
                    ?? HTTPURLResponse.localizedString(forStatusCode: http.statusCode)
            )
        }

        guard let object else {
            throw ServiceError.invalidResponse
        }
        return object
    }

    private func validateSuccess(_ object: [String: Any]) throws {
        if let success = object["success"] as? Bool, !success {
            throw ServiceError.api(message(from: object) ?? "TorBox request failed.")
        }
    }

    private func message(from object: [String: Any]?) -> String? {
        guard let object else { return nil }
        return string(in: object, keys: ["detail", "message", "error"])
    }

    private func integer(in object: Any, preferredKeys: [String]) -> Int? {
        if let number = object as? NSNumber { return number.intValue }
        if let string = object as? String { return Int(string) }

        if let dictionary = object as? [String: Any] {
            for key in preferredKeys {
                if let value = dictionary[key],
                   let result = integer(in: value, preferredKeys: preferredKeys) {
                    return result
                }
            }
        }
        return nil
    }

    private func int64(in dictionary: [String: Any], keys: [String]) -> Int64? {
        for key in keys {
            if let number = dictionary[key] as? NSNumber { return number.int64Value }
            if let string = dictionary[key] as? String, let value = Int64(string) { return value }
        }
        return nil
    }

    private func string(in dictionary: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let value = dictionary[key] as? String, !value.isEmpty {
                return value
            }
        }
        return nil
    }

    private func arrays(named key: String, in object: Any) -> [[Any]] {
        var results = [[Any]]()
        if let dictionary = object as? [String: Any] {
            if let array = dictionary[key] as? [Any] {
                results.append(array)
            }
            for value in dictionary.values {
                results.append(contentsOf: arrays(named: key, in: value))
            }
        } else if let array = object as? [Any] {
            for value in array {
                results.append(contentsOf: arrays(named: key, in: value))
            }
        }
        return results
    }

    private func findURLString(in object: Any) -> String? {
        if let string = object as? String,
           string.lowercased().hasPrefix("http") {
            return string
        }

        if let dictionary = object as? [String: Any] {
            for key in ["data", "url", "download_url", "link"] {
                if let value = dictionary[key],
                   let result = findURLString(in: value) {
                    return result
                }
            }
            for value in dictionary.values {
                if let result = findURLString(in: value) {
                    return result
                }
            }
        }

        if let array = object as? [Any] {
            for value in array {
                if let result = findURLString(in: value) {
                    return result
                }
            }
        }
        return nil
    }

    private struct MediaFile {
        let id: Int
        let name: String
        let size: Int64
    }
}

private extension Data {
    mutating func appendUTF8(_ value: String) {
        append(Data(value.utf8))
    }
}
