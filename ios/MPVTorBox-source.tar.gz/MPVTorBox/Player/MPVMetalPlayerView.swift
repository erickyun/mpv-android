import SwiftUI

struct MPVMetalPlayerView: UIViewControllerRepresentable {
    @ObservedObject var coordinator: Coordinator

    func makeUIViewController(context: Context) -> MPVMetalViewController {
        let controller = MPVMetalViewController()
        controller.playDelegate = coordinator
        controller.playURL = coordinator.playURL
        context.coordinator.player = controller
        return controller
    }

    func updateUIViewController(_ uiViewController: MPVMetalViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        coordinator
    }

    func play(_ url: URL) -> Self {
        coordinator.playURL = url
        return self
    }

    func onPropertyChange(
        _ handler: @escaping (MPVMetalViewController, String, Any?) -> Void
    ) -> Self {
        coordinator.onPropertyChange = handler
        return self
    }

    @MainActor
    final class Coordinator: MPVPlayerDelegate, ObservableObject {
        weak var player: MPVMetalViewController?
        var playURL: URL?
        var onPropertyChange: ((MPVMetalViewController, String, Any?) -> Void)?

        func play(_ url: URL) {
            playURL = url
            player?.loadFile(url)
        }

        func togglePause() {
            player?.togglePause()
        }

        func seek(seconds: Double) {
            player?.seek(seconds: seconds)
        }

        func propertyChange(mpv: OpaquePointer, propertyName: String, data: Any?) {
            guard let player else { return }
            onPropertyChange?(player, propertyName, data)
        }
    }
}
