import Foundation
import UIKit
import Libmpv

final class MPVMetalViewController: UIViewController {
    private let metalLayer = MetalLayer()
    private var mpv: OpaquePointer?
    private let eventQueue = DispatchQueue(label: "io.github.erickyun.mpv.events", qos: .userInitiated)

    weak var playDelegate: MPVPlayerDelegate?
    var playURL: URL?

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .black
        metalLayer.contentsScale = UIScreen.main.nativeScale
        metalLayer.framebufferOnly = true
        metalLayer.backgroundColor = UIColor.black.cgColor
        view.layer.addSublayer(metalLayer)

        setupMPV()

        if let playURL {
            loadFile(playURL)
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        metalLayer.frame = view.bounds
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
        if let mpv {
            mpv_terminate_destroy(mpv)
        }
    }

    private func setupMPV() {
        guard let context = mpv_create() else {
            assertionFailure("Unable to create mpv context")
            return
        }
        mpv = context

#if DEBUG
        check(mpv_request_log_messages(context, "warn"))
#else
        check(mpv_request_log_messages(context, "no"))
#endif

        check(mpv_set_option(context, "wid", MPV_FORMAT_INT64, &metalLayer))
        check(mpv_set_option_string(context, "vo", "gpu-next"))
        check(mpv_set_option_string(context, "gpu-api", "vulkan"))
        check(mpv_set_option_string(context, "gpu-context", "moltenvk"))
        check(mpv_set_option_string(context, "hwdec", "videotoolbox"))
        check(mpv_set_option_string(context, "profile", "fast"))
        check(mpv_set_option_string(context, "subs-match-os-language", "yes"))
        check(mpv_set_option_string(context, "subs-fallback", "yes"))
        check(mpv_set_option_string(context, "keep-open", "yes"))
        check(mpv_set_option_string(context, "idle", "yes"))

        check(mpv_initialize(context))
        mpv_observe_property(context, 0, MPVProperty.pausedForCache, MPV_FORMAT_FLAG)
        mpv_observe_property(context, 0, MPVProperty.videoParamsSigPeak, MPV_FORMAT_DOUBLE)

        mpv_set_wakeup_callback(
            context,
            { rawContext in
                guard let rawContext else { return }
                let controller = Unmanaged<MPVMetalViewController>
                    .fromOpaque(rawContext)
                    .takeUnretainedValue()
                controller.readEvents()
            },
            Unmanaged.passUnretained(self).toOpaque()
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(didEnterBackground),
            name: UIApplication.didEnterBackgroundNotification,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(willEnterForeground),
            name: UIApplication.willEnterForegroundNotification,
            object: nil
        )
    }

    func loadFile(_ url: URL) {
        command("loadfile", args: [url.absoluteString, "replace"])
    }

    func togglePause() {
        getFlag(MPVProperty.pause) ? setFlag(MPVProperty.pause, false) : setFlag(MPVProperty.pause, true)
    }

    func seek(seconds: Double) {
        command("seek", args: [String(seconds), "relative+exact"])
    }

    @objc private func didEnterBackground() {
        setFlag(MPVProperty.pause, true)
        setString("vid", value: "no")
    }

    @objc private func willEnterForeground() {
        setString("vid", value: "auto")
    }

    private func command(_ name: String, args: [String]) {
        guard let mpv else { return }

        var strings = [name] + args
        var pointers: [UnsafePointer<CChar>?] = strings.map { strdup($0).map(UnsafePointer.init) }
        pointers.append(nil)

        defer {
            for pointer in pointers.compactMap({ $0 }) {
                free(UnsafeMutablePointer(mutating: pointer))
            }
        }

        pointers.withUnsafeMutableBufferPointer {
            check(mpv_command(mpv, $0.baseAddress))
        }
    }

    private func getFlag(_ name: String) -> Bool {
        guard let mpv else { return false }
        var value: Int64 = 0
        mpv_get_property(mpv, name, MPV_FORMAT_FLAG, &value)
        return value != 0
    }

    private func setFlag(_ name: String, _ value: Bool) {
        guard let mpv else { return }
        var flag: Int32 = value ? 1 : 0
        check(mpv_set_property(mpv, name, MPV_FORMAT_FLAG, &flag))
    }

    private func setString(_ name: String, value: String) {
        guard let mpv else { return }
        check(mpv_set_property_string(mpv, name, value))
    }

    private func readEvents() {
        eventQueue.async { [weak self] in
            guard let self, let mpv = self.mpv else { return }

            while true {
                guard let event = mpv_wait_event(mpv, 0) else { return }
                if event.pointee.event_id == MPV_EVENT_NONE { return }

                switch event.pointee.event_id {
                case MPV_EVENT_PROPERTY_CHANGE:
                    guard let data = event.pointee.data else { continue }
                    let property = data.assumingMemoryBound(to: mpv_event_property.self).pointee
                    guard let namePointer = property.name else { continue }
                    let name = String(cString: namePointer)

                    if name == MPVProperty.pausedForCache {
                        let value = property.data?.assumingMemoryBound(to: Int32.self).pointee ?? 0
                        Task { @MainActor [weak self] in
                            guard let self, let mpv = self.mpv else { return }
                            self.playDelegate?.propertyChange(
                                mpv: mpv,
                                propertyName: name,
                                data: value != 0
                            )
                        }
                    }

                case MPV_EVENT_LOG_MESSAGE:
#if DEBUG
                    if let data = event.pointee.data {
                        let message = data.assumingMemoryBound(to: mpv_event_log_message.self).pointee
                        if let text = message.text {
                            print(String(cString: text), terminator: "")
                        }
                    }
#endif

                case MPV_EVENT_SHUTDOWN:
                    return

                default:
                    continue
                }
            }
        }
    }

    private func check(_ status: CInt) {
        if status < 0 {
            print("mpv error: \(String(cString: mpv_error_string(status)))")
        }
    }
}
