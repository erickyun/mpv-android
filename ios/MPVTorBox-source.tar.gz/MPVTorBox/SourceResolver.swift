import Foundation

struct ResolvedSource {
    let url: URL
    let provider: String
}

struct SourceResolver {
    enum ResolverError: LocalizedError {
        case emptySource
        case invalidSource
        case noTorrentProvider
        case torBoxFailed(String)

        var errorDescription: String? {
            switch self {
            case .emptySource:
                return "Paste a magnet link or media URL."
            case .invalidSource:
                return "The source is not a valid magnet link or URL."
            case .noTorrentProvider:
                return "Enable TorBox or TorrServer in Advanced settings."
            case .torBoxFailed(let message):
                return "TorBox failed: \(message)"
            }
        }
    }

    private let torBox = TorBoxService()

    func resolve(
        _ input: String,
        settings: ProviderSettings,
        status: @escaping @MainActor (String) -> Void
    ) async throws -> ResolvedSource {
        let source = normalizedSource(input)
        guard !source.isEmpty else { throw ResolverError.emptySource }

        if isMagnet(source) {
            var torBoxError: Error?

            if settings.torBoxEnabled, !settings.torBoxAPIKey.isEmpty {
                do {
                    let url = try await torBox.resolve(
                        magnet: source,
                        apiKey: settings.torBoxAPIKey,
                        status: status
                    )
                    return ResolvedSource(url: url, provider: "TorBox")
                } catch {
                    torBoxError = error
                }
            }

            if settings.torrServerEnabled {
                await status("Opening through TorrServer…")
                let url = try TorrServerService.streamURL(
                    source: source,
                    serverAddress: settings.torrServerAddress
                )
                return ResolvedSource(url: url, provider: "TorrServer")
            }

            if let torBoxError {
                throw ResolverError.torBoxFailed(torBoxError.localizedDescription)
            }
            throw ResolverError.noTorrentProvider
        }

        guard let url = URL(string: source),
              let scheme = url.scheme?.lowercased(),
              ["http", "https", "file"].contains(scheme) else {
            throw ResolverError.invalidSource
        }

        await status("Opening media URL…")
        return ResolvedSource(url: url, provider: "Direct")
    }

    private func normalizedSource(_ input: String) -> String {
        let trimmed = input.trimmingCharacters(in: .whitespacesAndNewlines)

        if let url = URL(string: trimmed),
           url.scheme?.lowercased() == "mpvtorbox",
           let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
           let embedded = components.queryItems?.first(where: { $0.name == "url" })?.value {
            return embedded
        }

        return trimmed
    }

    private func isMagnet(_ source: String) -> Bool {
        let lower = source.lowercased()
        return lower.hasPrefix("magnet:") || lower.hasPrefix("torrs://")
    }
}
