import Foundation

enum TorrServerService {
    enum ServiceError: LocalizedError {
        case invalidAddress

        var errorDescription: String? {
            "The TorrServer address is invalid."
        }
    }

    static func streamURL(source: String, serverAddress: String) throws -> URL {
        let cleaned = serverAddress
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))

        guard var components = URLComponents(string: cleaned),
              components.scheme == "http" || components.scheme == "https",
              components.host != nil else {
            throw ServiceError.invalidAddress
        }

        let basePath = components.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        components.path = "/"
            + ([basePath, "stream", "torrent.m3u"].filter { !$0.isEmpty }.joined(separator: "/"))
        components.queryItems = [
            URLQueryItem(name: "link", value: source),
            URLQueryItem(name: "m3u", value: nil)
        ]

        guard let url = components.url else {
            throw ServiceError.invalidAddress
        }
        return url
    }
}
