import SwiftUI
import UIKit

struct ContentView: View {
    @EnvironmentObject private var settings: AppSettings

    @StateObject private var playerCoordinator = MPVMetalPlayerView.Coordinator()
    @State private var sourceText = ""
    @State private var isResolving = false
    @State private var statusText = "Paste a magnet link or media URL."
    @State private var errorMessage: String?
    @State private var currentSource: ResolvedSource?
    @State private var showingSettings = false
    @State private var showingPlayer = false

    private let resolver = SourceResolver()

    var body: some View {
        NavigationStack {
            VStack(spacing: 18) {
                Spacer(minLength: 18)

                Image(systemName: "play.rectangle.fill")
                    .font(.system(size: 64))
                    .foregroundStyle(.tint)

                Text("MPV TorBox")
                    .font(.largeTitle.bold())

                Text("Open magnet links with TorBox or TorrServer and play them with MPVKit.")
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)

                TextEditor(text: $sourceText)
                    .font(.system(.body, design: .monospaced))
                    .frame(minHeight: 130)
                    .padding(8)
                    .background(
                        RoundedRectangle(cornerRadius: 14)
                            .fill(Color(uiColor: .secondarySystemBackground))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 14)
                            .stroke(Color.secondary.opacity(0.25))
                    )
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .padding(.horizontal)

                HStack {
                    Button {
                        sourceText = UIPasteboard.general.string ?? ""
                    } label: {
                        Label("Paste", systemImage: "doc.on.clipboard")
                    }
                    .buttonStyle(.bordered)

                    Button {
                        openSource()
                    } label: {
                        if isResolving {
                            ProgressView()
                                .padding(.horizontal, 14)
                        } else {
                            Label("Play", systemImage: "play.fill")
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isResolving || sourceText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }

                Text(statusText)
                    .font(.footnote)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal)

                Spacer()
            }
            .navigationTitle("Open URL")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showingSettings = true
                    } label: {
                        Image(systemName: "gearshape")
                    }
                    .accessibilityLabel("Advanced settings")
                }
            }
            .sheet(isPresented: $showingSettings) {
                AdvancedSettingsView()
                    .environmentObject(settings)
            }
            .fullScreenCover(isPresented: $showingPlayer) {
                if let currentSource {
                    PlayerScreen(
                        source: currentSource,
                        coordinator: playerCoordinator,
                        isPresented: $showingPlayer
                    )
                }
            }
            .alert("Unable to play", isPresented: Binding(
                get: { errorMessage != nil },
                set: { if !$0 { errorMessage = nil } }
            )) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(errorMessage ?? "Unknown error")
            }
            .onOpenURL { url in
                sourceText = sourceString(from: url)
                openSource()
            }
        }
    }

    private func openSource() {
        let input = sourceText
        let providerSettings = settings.snapshot()

        isResolving = true
        statusText = "Resolving source…"

        Task {
            do {
                let resolved = try await resolver.resolve(
                    input,
                    settings: providerSettings
                ) { message in
                    statusText = message
                }

                currentSource = resolved
                statusText = "Playing through \(resolved.provider)."
                playerCoordinator.play(resolved.url)
                showingPlayer = true
            } catch {
                errorMessage = error.localizedDescription
                statusText = "Unable to resolve source."
            }
            isResolving = false
        }
    }

    private func sourceString(from url: URL) -> String {
        if url.scheme?.lowercased() == "mpvtorbox",
           let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
           let embedded = components.queryItems?.first(where: { $0.name == "url" })?.value {
            return embedded
        }
        return url.absoluteString
    }
}

private struct PlayerScreen: View {
    let source: ResolvedSource
    @ObservedObject var coordinator: MPVMetalPlayerView.Coordinator
    @Binding var isPresented: Bool

    @State private var loading = false
    @State private var controlsVisible = true

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            MPVMetalPlayerView(coordinator: coordinator)
                .play(source.url)
                .onPropertyChange { _, propertyName, data in
                    if propertyName == MPVProperty.pausedForCache {
                        loading = data as? Bool ?? false
                    }
                }
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation {
                        controlsVisible.toggle()
                    }
                }

            if loading {
                ProgressView()
                    .controlSize(.large)
                    .tint(.white)
            }

            if controlsVisible {
                VStack {
                    HStack {
                        Button {
                            isPresented = false
                        } label: {
                            Image(systemName: "xmark")
                                .font(.headline)
                                .frame(width: 44, height: 44)
                                .background(.ultraThinMaterial, in: Circle())
                        }

                        Spacer()

                        Text(source.provider)
                            .font(.caption.bold())
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(.ultraThinMaterial, in: Capsule())
                    }
                    .padding()

                    Spacer()

                    HStack(spacing: 30) {
                        Button {
                            coordinator.seek(seconds: -15)
                        } label: {
                            Image(systemName: "gobackward.15")
                        }

                        Button {
                            coordinator.togglePause()
                        } label: {
                            Image(systemName: "playpause.fill")
                                .font(.title)
                        }

                        Button {
                            coordinator.seek(seconds: 15)
                        } label: {
                            Image(systemName: "goforward.15")
                        }
                    }
                    .font(.title2)
                    .padding(.horizontal, 28)
                    .padding(.vertical, 16)
                    .background(.ultraThinMaterial, in: Capsule())
                    .padding(.bottom, 28)
                }
                .foregroundStyle(.white)
                .transition(.opacity)
            }
        }
        .statusBarHidden()
    }
}
