import Foundation

@MainActor
final class AppSettings: ObservableObject {
    private enum Keys {
        static let torBoxEnabled = "torbox_enabled"
        static let torrServerEnabled = "torrserver_enabled"
        static let torrServerAddress = "torrserver_address"
        static let torBoxAPIKey = "torbox_api_key"
    }

    @Published var torBoxEnabled: Bool {
        didSet { defaults.set(torBoxEnabled, forKey: Keys.torBoxEnabled) }
    }

    @Published var torrServerEnabled: Bool {
        didSet { defaults.set(torrServerEnabled, forKey: Keys.torrServerEnabled) }
    }

    @Published var torrServerAddress: String {
        didSet { defaults.set(torrServerAddress, forKey: Keys.torrServerAddress) }
    }

    @Published private(set) var torBoxAPIKey: String

    private let defaults = UserDefaults.standard

    init() {
        if defaults.object(forKey: Keys.torBoxEnabled) == nil {
            defaults.set(true, forKey: Keys.torBoxEnabled)
        }
        if defaults.object(forKey: Keys.torrServerEnabled) == nil {
            defaults.set(false, forKey: Keys.torrServerEnabled)
        }

        torBoxEnabled = defaults.bool(forKey: Keys.torBoxEnabled)
        torrServerEnabled = defaults.bool(forKey: Keys.torrServerEnabled)
        torrServerAddress = defaults.string(forKey: Keys.torrServerAddress) ?? "http://127.0.0.1:8090"
        torBoxAPIKey = KeychainStore.read(account: Keys.torBoxAPIKey)
    }

    func saveTorBoxAPIKey(_ value: String) throws {
        let cleaned = value.trimmingCharacters(in: .whitespacesAndNewlines)
        try KeychainStore.write(cleaned, account: Keys.torBoxAPIKey)
        torBoxAPIKey = cleaned
    }

    func snapshot() -> ProviderSettings {
        ProviderSettings(
            torBoxEnabled: torBoxEnabled,
            torBoxAPIKey: torBoxAPIKey,
            torrServerEnabled: torrServerEnabled,
            torrServerAddress: torrServerAddress
        )
    }
}

struct ProviderSettings: Sendable {
    let torBoxEnabled: Bool
    let torBoxAPIKey: String
    let torrServerEnabled: Bool
    let torrServerAddress: String
}
